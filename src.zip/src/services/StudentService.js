import http from "./http-common";

class StudentService {
  getAll() {
    return http.get("/student");
  }

  get(id) {
    return http.get(`/api/student/${id}`);
  }
  create(student) {
    return http.post("/api/student/register", student);
  }
  update(email, student) {
    return http.put(`/api/student/${email}`, student);
  }
  delete(email) {
    return http.delete(`/api/student/${email}`);
  }
  changePassword(email, oldpassword, newpassword) {
    return http.put(`/api/student/changepassword/${email}/${oldpassword}/${newpassword}`)
  }
}

export default new StudentService();
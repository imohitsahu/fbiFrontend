import http from "./http-common";

class AdminService {
  getAll() {
    return http.get("/api/institute");
  }

  get(id) {
    return http.get(`/api/institute/${id}`);
  }
  create(institute) {
    return http.post("/api/institute/register", institute);
  }
  update(email, institute) {
    return http.put(`/api/institute/${email}`, institute);
  }
  delete(email) {
    return http.delete(`/api/institute/${email}`);
  }
  changePassword(email, oldpassword, newpassword) {
    return http.put(`/api/admin/changepassword/${email}/${oldpassword}/${newpassword}`)
  }
}

export default new AdminService();
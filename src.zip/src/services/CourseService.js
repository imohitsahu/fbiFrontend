import http from "./http-common";

class CourseService {

  get(insEmail) {
    return http.get(`/getAllCoursesByEmail/${insEmail}`);
  }
  create(course) {
    return http.post("/api/course/register", course);
  }
  delete(id) {
    return http.delete(`/api/course/${id}`);
  }
}

export default new CourseService();
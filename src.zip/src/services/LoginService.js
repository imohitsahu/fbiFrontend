import http from "./http-common";

class LoginService {
  login(email, password) {
    return http.put(`/login/${email}/${password}`);
  }
  logout(email){
    return http.put(`/logout/${email}`);
  }
  forgetpassword(email){
    return http.get(`/forgetpassword/${email}`);
  }
  
}
export default new LoginService();
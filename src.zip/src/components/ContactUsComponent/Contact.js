import React from "react"
import Header from "../Header"
import Contact from "./Contact_temp"
import Footer from "../Footer"

const ContactUs = () => {
    return(
        <React.Fragment>
            <Header />
            <Contact />
            <Footer />
        </React.Fragment>
    )
}
export default ContactUs;
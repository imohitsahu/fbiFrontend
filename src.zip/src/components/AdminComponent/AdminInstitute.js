import axios from "axios";
import React, { useEffect, useState } from "react";
import { Button } from 'react-bootstrap'
import { Modal } from 'react-bootstrap'
import "./AdstudentList.css"
import AdminNav from "./AdminNav";
import AdminHeader from "./AdminHeader";

export default function AllInstitute() {
    const [show, setShow] = useState(false)
    const handleShow = () => setShow(true);
    const handleClose = () => setShow(false);
    const [instituteTemp, SetInstituteTemp] = useState({
        email: "",
        insName: "",
        password: "",
        contactNo: "",
        city: "",
        state: "",
        map: "",
        status: ""
    })

    const [insName, SetInsName] = useState('')
    const [email, SetEmail] = useState('')
    const [contactNo, SetContactNo] = useState('')
    const [city, SetCity] = useState('')
    const [password, SetPassword] = useState('')
    const [state, SetState] = useState('')
    const [map, SetMap] = useState('')
    const [status, SetStatus] = useState('')

    const [apiData, setApiData] = useState([]);

    useEffect(() => {
        axios.get(`http://localhost:8080/api/institute/all_institutes`)
            .then((getData) => {
                setApiData(getData.data);
            })
    }, [])

    const setData = (insName, email, contactNo, state, city, password, map, status) => {
        localStorage.setItem('Name', insName)
        localStorage.setItem('email', email)
        localStorage.setItem('contactNo', contactNo)
        localStorage.setItem('state', state)
        localStorage.setItem('city', city)
        localStorage.setItem('map', map)
        localStorage.setItem('status', status)
    }

    const setID = (email) => {
        console.log(email)
        localStorage.setItem('Email', email)
    }

    const getData = () => {
        axios.get('http://localhost:8080/api/student/all_Institutes')
            .then((getData) => {
                setApiData(getData.data);
            })
    }

    const onDelete = (email) => {
        axios.delete(`http://localhost:8080/api/institute/${email}`)
            .then(() => {
                getData();
            })
        window.location.reload(false);
    }

    const sendDataToAPI = () => {
        axios.put(`http://localhost:8080/api/institute/${instituteTemp.email}`, instituteTemp)
            .then((response) => {
                alert('Successfully Update', JSON.stringify(instituteTemp))
            })
        window.location.reload(false);

    }

    const updateInstitute = (email) => {
        SetInstituteTemp({
            email: apiData.find(it => it.email === email).email,
            insName: apiData.find(it => it.email === email).insName,
            password: apiData.find(it => it.email === email).password,
            contactNo: apiData.find(it => it.email === email).contactNo,
            city: apiData.find(it => it.email === email).city,
            state: apiData.find(it => it.email === email).state,
            map: apiData.find(it => it.email === email).map,
            status: apiData.find(it => it.email === email).status,
        })
        setShow(true)
    }

    const changeHandleInstitute = (e) => {
        SetInstituteTemp((prevData) => ({
            ...prevData,
            [e.target.name]: e.target.value
        }))
    };
    let index = 0

    return (
        <div>
            <AdminHeader />
            <AdminNav />
            <div className="tab-pane fade show active">
                <div className="p-3  mx-auto text-center">
                    <table className="table table-responsive mx-auto table-striped" id="table-id">
                        <thead>
                            <tr>
                                <th>S.No.</th>
                                <th>Institute Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>City</th>
                                <th>State</th>
                                <th>Map</th>
                                <th>Update</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            {apiData.map((data) => {
                                index++
                                return (
                                    <tr>
                                        <td>{index}</td>
                                        <td>{data.insName}</td>
                                        <td>{data.email}</td>
                                        <td>{data.contactNo}</td>
                                        <td>{data.city}</td>
                                        <td>{data.state}</td>
                                        <td>
                                            <a href={data.map} target="blank">Map</a>
                                        </td>
                                        <td>
                                            <Button onClick={() => updateInstitute(data.email)} variant="secondary" style={{ backgroundColor: "#15B5B0" }}>
                                                Update
                                            </Button>
                                        </td>
                                        <td>
                                            <Button onClick={() => onDelete(data.email)} variant="secondary" style={{ backgroundColor: "#bd2130" }} >
                                                Delete
                                            </Button>
                                        </td>
                                    </tr>
                                )
                            })}

                        </tbody>
                    </table>
                    <div className='pagination-container'>
                        <nav>
                            <ul className="pagination">
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
            <Modal show={show} onHide={handleClose} >
                <Modal.Header closeButton>
                    <Modal.Title>Update Institute</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <form className="form-body" >
                        <p>Update</p>
                        <div className="username">
                            <label className="form__label">Full Name </label>
                            <input className="form__input" type="text" name="insName" placeholder="Your Name" value={instituteTemp.insName} onChange={changeHandleInstitute} required />
                        </div>

                        <div className="email">
                            <label className="form__label">Email </label>
                            <input type="email" className="form__input" name="email" placeholder="Email" value={instituteTemp.email}
                                pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Email should be in valid format.(ex: example@gmail.com)" onChange={changeHandleInstitute} readOnly />
                        </div>

                        <div className="contactno">
                            <label className="form__label">Phone No. </label>
                            <input type="tel" className="form__input" name="contactNo" placeholder="12345-67890" onChange={changeHandleInstitute} pattern="^\d{10}$" title="Phone number should be in 10 digits without alphabets"
                                value={instituteTemp.contactNo} required />
                        </div>

                        <div className="city d-flex">
                            <label className="form__label">City</label>
                            <input type="text" className="form__input" name="city" placeholder="city" value={instituteTemp.city} onChange={changeHandleInstitute} required />
                        </div>

                        <div className="state d-flex">
                            <label className="form__label">State </label>
                            <input type="text" className="form__input" name="state" placeholder="state" value={instituteTemp.state} onChange={changeHandleInstitute} required />
                        </div>

                        <div className="mt-3">
                            <Button variant="secondary" onClick={sendDataToAPI} style={{ backgroundColor: "#15B5B0" }}>
                                Update
                            </Button>
                        </div>
                    </form>

                </Modal.Body>
                <div className='text-center'>
                    {/* {success && <p className='text-center text-success'>{successMsg}</p>}
                            {failure && <p className='text-center text-danger'>{failureMsg}</p>} */}
                </div>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose} style={{ backgroundColor: "#bd2130" }}>
                        Close
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    )
}


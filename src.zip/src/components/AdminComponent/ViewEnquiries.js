import axios from "axios";
import React, { useEffect, useState } from "react";
import { Button } from 'react-bootstrap'
import { Modal } from 'react-bootstrap'
import "./AdstudentList.css"
import { Link } from "react-router-dom";
import AdminNav from "./AdminNav";
import StuHeader from "../StudentComponent/StuHeader";
import AdminHeader from "./AdminHeader";

export default function AllEnquiries() {
    const [apiData, setApiData] = useState([]);

    useEffect(() => {
        axios.get(`http://localhost:8080/api/Enquiry/allEnquiries`)
            .then((getData) => {
                setApiData(getData.data);
            })
    }, [])

    const setID = (enqId) => {
        console.log(enqId)
        localStorage.setItem('enqId', enqId)
    }

    const getData = () => {
        axios.get(`http://localhost:8080/api/Enquiry/allEnquiries`)
            .then((getData) => {
                setApiData(getData.data);
            })
    }

    const onDelete = (enqId) => {
        axios.delete(`http://localhost:8080/api/Enquiry/${enqId}`)
            .then(() => {
                getData();
            })
        // window.location.reload(false);
    }
    let index = 0;

    return (
        <div>
            <AdminHeader />
            <AdminNav />
            <div className="tab-pane fade show active">
                <div className="p-3  mx-auto text-center">
                    <table className="table table-responsive mx-auto table-striped" id="table-id">


                        <thead>
                            <tr>
                                <th>S.No.</th>
                                <th>Student Email</th>
                                <th>Student Name</th>
                                <th>Institute Email</th>
                                <th>Enquiry Summary</th>
                                <th>phone no</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            {apiData.map((data) => {
                                index++
                                return (
                                    <tr>
                                        <td>{index}</td>
                                        <td>{data.stuEmail}</td>
                                        <td>{data.stuName}</td>
                                        <td>{data.insEmail}</td>
                                        <td>{data.enquiry}</td>
                                        <td>{data.phoneNo}</td>
                                        <td>
                                            <Button variant="secondary" style={{ backgroundColor: "#bd2130" }} onClick={() => onDelete(data.email)}>
                                                Delete
                                            </Button>
                                        </td>
                                    </tr>
                                )
                            })}

                        </tbody>
                    </table>
                    <div className='pagination-container'>
                        <nav>
                            <ul className="pagination">
                            </ul>
                        </nav>
                    </div>

                </div>
            </div>
        </div>
    )
}


import axios from "axios";
import React, { useEffect, useState } from "react";
import { Button } from 'react-bootstrap'
import { Modal } from 'react-bootstrap'
import "./AdstudentList.css"
import AdminNav from "./AdminNav";
import AdminHeader from "./AdminHeader";

export default function AllStudent() {
    const [show, setShow] = useState(false)
    const handleShow = () => setShow(true);
    const handleClose = () => setShow(false);
    const [studentTemp, SetStudentTemp] = useState({
        email: "",
        stuName: "",
        password: "",
        contactNo: "",
        city: "",
        state: "",
    })

    const [stuName, SetStuName] = useState('')
    const [email, SetEmail] = useState('')
    const [contactNo, SetContactNo] = useState('')
    const [city, SetCity] = useState('')
    const [password, SetPassword] = useState('')
    const [state, SetState] = useState('')

    const [apiData, setApiData] = useState([]);

    useEffect(() => {
        axios.get(`http://localhost:8080/api/student/all_Students`)
            .then((getData) => {
                setApiData(getData.data);
            })
    }, [])

    const setData = (stuName, email, contactNo, state, city, password) => {
        localStorage.setItem('Name', stuName)
        localStorage.setItem('email', email)
        localStorage.setItem('contactNo', contactNo)
        localStorage.setItem('state', state)
        localStorage.setItem('city', city)
        localStorage.setItem('password', password)
    }

    const setID = (email) => {
        console.log(email)
        localStorage.setItem('Email', email)
    }

    const getData = () => {
        axios.get(`http://localhost:8080/api/student/all_Students`)
            .then((getData) => {
                setApiData(getData.data);
            })
    }

    const onDelete = (email) => {
        axios.delete(`http://localhost:8080/api/student/${email}`)
            .then(() => {
                getData();
            })
        window.location.reload(false);
    }

    const sendDataToAPI = () => {
        axios.put(`http://localhost:8080/api/student/${studentTemp.email}`, studentTemp)
            .then((response) => {
                alert('Successfully Update', JSON.stringify(studentTemp))
            })
    }

    const updateStudent = (email) => {
        SetStudentTemp({
            email: apiData.find(it => it.email === email).email,
            stuName: apiData.find(it => it.email === email).stuName,
            password: apiData.find(it => it.email === email).password,
            contactNo: apiData.find(it => it.email === email).contactNo,
            city: apiData.find(it => it.email === email).city,
            state: apiData.find(it => it.email === email).state,
        })
        setShow(true)
    }

    const changeHandleStudent = (e) => {
        SetStudentTemp((prevData) => ({
            ...prevData,
            [e.target.name]: e.target.value
        }))
    };
    let index = 0

    return (
        <div>
            <AdminHeader />
            <AdminNav />
            <div className='tab-pane fade show active'>
                <div className="p-3  mx-auto text-center">
                    <table className="table table-responsive mx-auto table-striped">
                        <thead>
                            <tr>
                                <th>S.No.</th>
                                <th>Student Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>City</th>
                                <th>State</th>
                                <th>Update</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            {apiData.map((data) => {
                                index++
                                return (
                                    <tr>
                                        <td>{index}</td>
                                        <td>{data.stuName}</td>
                                        <td>{data.email}</td>
                                        <td>{data.contactNo}</td>
                                        <td>{data.city}</td>
                                        <td>{data.state}</td>
                                        <td>
                                            <Button onClick={() => updateStudent(data.email)} variant="secondary" style={{ backgroundColor: "#15B5B0" }}>
                                                Update
                                            </Button>
                                        </td>
                                        <td>
                                            <Button variant="secondary" style={{ backgroundColor: "#bd2130" }} onClick={() => onDelete(data.email)}>
                                                Delete
                                            </Button>
                                        </td>
                                    </tr>
                                )
                            })}

                        </tbody>
                    </table>
                    <div className='pagination-container'>
                        <nav>
                            <ul className="pagination">
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
            <Modal show={show} onHide={handleClose} >
                <Modal.Header closeButton>

                    <Modal.Title>Update Student</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <form className="form-body" >
                        <p>Update</p>
                        <div className="username">
                            <label className="form__label">Full Name </label>
                            <input className="form__input" type="text" name="stuName" placeholder="Your Name" value={studentTemp.stuName} onChange={changeHandleStudent} required />
                        </div>

                        <div className="email">
                            <label className="form__label">Email </label>
                            <input type="email" className="form__input" name="email" placeholder="Email" value={studentTemp.email}
                                pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Email should be in valid format.(ex: example@gmail.com)" onChange={changeHandleStudent} required />
                        </div>

                        <div className="contactno">
                            <label className="form__label">Phone No. </label>
                            <input type="tel" className="form__input" name="contactNo" placeholder="12345-67890" onChange={changeHandleStudent} pattern="^\d{10}$" title="Phone number should be in 10 digits without alphabets"
                                value={studentTemp.contactNo} required />
                        </div>

                        <div className="city d-flex">
                            <label className="form__label">City</label>
                            <input type="text" className="form__input" name="city" placeholder="city" value={studentTemp.city} onChange={changeHandleStudent} required />
                        </div>

                        <div className="state d-flex">
                            <label className="form__label">State </label>
                            <input type="text" className="form__input" name="state" placeholder="state" value={studentTemp.state} onChange={changeHandleStudent} required />
                        </div>

                        <div className="password">
                            <label className="form__label">Password </label>
                            <input className="form__input" name="password" type="password" placeholder="Password" value={studentTemp.password} onChange={changeHandleStudent} required />
                        </div>
                        <div className="mt-3">
                            <Button variant="secondary" onClick={sendDataToAPI} style={{ backgroundColor: "#15B5B0" }}>
                                Submit
                            </Button>
                            {/* <input type="submit" className="btn text-white form-control" value="Update"/> */}
                        </div>
                    </form>

                </Modal.Body>
                <div className='text-center'>
                    {/* {success && <p className='text-center text-success'>{successMsg}</p>}
                            {failure && <p className='text-center text-danger'>{failureMsg}</p>} */}
                </div>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose} style={{ backgroundColor: "#bd2130" }}>
                        Close
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    )
}


import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from 'react-router-dom';
import axios from "axios";
import InstituteService from "../../services/InstituteService"
import { Button, Modal } from "react-bootstrap";
import StudentService from '../../services/StudentService'

export default function StudentHome() {
  const [show, setShow] = useState(false);
  const handleShow = () => setShow(true);
  const handleClose = () => setShow(false);

  const [stuEmail, setStuEmail] = useState("msahu7362@gmail.com");
  const [stuName, setStuName] = useState();
  const [phoneNo, setPhoneNo] = useState();

  const [apiData, setApiData] = useState([]);
  useEffect(() => {
    axios.get(`http://localhost:8080/api/institute/all_institutes`)
      .then((getData) => {
        setApiData(getData.data)
      })
   axios.get(`http://localhost:8080/api/student/${stuEmail}`)
      .then((res) => {
        setStuName(res.data.stuName);
        setStuEmail(res.data.email);
        setPhoneNo(res.data.contactNo);
        console.log(res.data);
      })

  }, [])

  const [courseData, setCourseData] = useState([]);
  const coursesOfInstitute = (email) => {
    axios.get(`http://localhost:8080/api/course/getAllCoursesByEmail/${email}`)
      .then((getData) => {
        console.log(getData.data)
        setCourseData(getData.data);
      })
    setShow(true)
  }
  let index = 0;

  const onEnqury = (insEmail, insName) => {
    let enquiryDto = {
      "insEmail": insEmail,
      "insName": insName,
      "stuName": stuName,
      "stuEmail": stuEmail,
      "phoneNo": phoneNo
    }
    // alert(JSON.stringify(enquiryDto))
    axios.post(`http://localhost:8080/api/Enquiry/enquiry`, enquiryDto)
      .then((getData) => {
        alert("Enquiry added Successfully")
      })
      .catch(error =>{
        alert("Already Raised Enquiry")
      })

  }

  return (
    <div className="container mt-1" style={{ minHeight: "500px" }}>
      <div className="row">

        {apiData.map((data) => {
          return (
            <div className="col-lg-4">
              <div className="data mt-4 rounded border">
                <h2 className="text-center p-4 display-3 text-white" style={{ backgroundColor: "blueviolet" }}><b>{data.insName[0]}</b></h2>
                <table className="table table-sm table-striped" style={{ minHeight: "167px", fontSize: "18px" }} >
                  <tr className="">
                    <td className="p-0  pl-3"><small>Institute Name : </small></td>
                    <td className="p-0"><small>{data.insName}</small></td>
                  </tr>
                  <tr className="">
                    <td className="p-0  pl-3"><small>City : </small></td>
                    <td className="p-0"><small>{data.city}</small></td>
                  </tr>
                  <tr className="">
                    <td className="p-0  pl-3"><small>State : </small></td>
                    <td className="p-0"><small>{data.state}</small></td>
                  </tr>
                  <tr className="">
                    <td className="p-0  pl-3"><small>Office Number : </small></td>
                    <td className="p-0"><small>{data.contactNo}</small></td>
                  </tr>
                  <tr className="">
                    <td className="p-0  pl-3"><small>Email : </small></td>
                    <td className="p-0"><small>{data.email}</small></td>
                  </tr>

                  {/* <tr className="">
                      <td className="p-0  pl-3"><small>Distance From You</small></td>
                      <td className="p-0"><small className="badge border">near</small></td> */}
                  {/* (( getDistanceFromLatLonInKm(x.institute.lat , x.institute.lng, student.lat , student.lng) )) KM */}
                  {/* </tr> */}
                  {/* <tr className="">
                    <td className="p-0  pl-3"><small>Rating</small></td>
                    <td className="p-0">
                      <i className="fa fa-star p-0 m-0 text-success" ng-repeat='i in getNumbers(x.avgrate)'></i>
                      <i className="fa fa-star-o p-0 m-0" ng-repeat='i in getNumbers(5-x.avgrate)'></i>
                    </td>
                  </tr> */}
                </table>
                {/* <tr className="">
              <td className="p-0  pl-3"><small>Course</small></td>
              <td className="p-0"><small>((x.courseName))</small></td>
            </tr>
            <tr className="">
              <td className="p-0  pl-3"><small>Course Fees</small></td>
              <td className="p-0"><small>Rs. ((x.courseFees))</small></td>
            </tr> */}
                <div className="row text-center">
                  <div className="col-lg-4 mt-2">
                    <button className="btn btn-sm bg-white text-info border" onClick={() => coursesOfInstitute(data.email)} >More Info</button>
                  </div>
                  <div className="col-lg-4 mt-2">
                    <a className="btn border btn-sm btn-white text-dark bg-white" target="blank" href={data.map}
                      style={{ textDecoration: "none" }}>See On Map <span className="material-icons icon"></span></a>
                  </div>
                  <div className="col-lg-4 mt-2">
                    <Button onClick={() => onEnqury(data.email, data.insName)} className="btn border btn-sm btn-white text-dark bg-white"
                      style={{ textDecoration: "none" }}>Enquery<span className="material-icons icon"></span></Button>
                  </div>
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* <!-- Modal --> */}
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Courses Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>

          <table className="table table-responsive mx-auto table-striped">
            <thead>
              <tr>
                <th>Sno.</th>
                <th>Course</th>
                <th>Course Fees</th>
              </tr>
            </thead>
            <tbody>
              {courseData.map((data) => {
                index++
                return (
                  <tr>
                    <td>{index}</td>
                    <td>{data.courseName}</td>
                    <td>Rs. {data.courseFee} </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </Modal.Body>
      </Modal>
    </div >
  )
}
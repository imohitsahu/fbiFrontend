import React, { useState, useEffect } from "react";
import { useNavigate, useLocation, Link } from 'react-router-dom';
import StudentService from "../../services/StudentService";
import General from "./profile/General";
import StuHeader from "./StuHeader";

function StudentProfile() {

  return (
    <>
      <div className="container" ng-app='studentProfileApp' ng-controller='studentProfileController'>
        <div className="text-center p-3">
          <p className="p-2">student-name</p>
        </div>
        <div className="nav nav-tabs" id="nav-tab" role="tablist">
          <Link className="nav-item nav-link" data-toggle="tab" to="/gen" role="tab">General</Link>
          <Link className="nav-item nav-link" data-toggle="tab" to="/stupassword" role="tab">Password</Link>
          <Link className="nav-item nav-link" data-toggle="tab" to="" role="tab">Course of Institute</Link>
          <Link className="nav-item nav-link" data-toggle="tab" to="/courseofstudent" role="tab">Course</Link>
        </div>
      </div>
    </>
  )
}
export default StudentProfile;
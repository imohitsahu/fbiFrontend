// import React, {useState} from "react"

// const searchBar = () => {
//     const [searchInput, setSearchInput] = useState("");

//     const cities = [
//         { label: 'Bhopal', value: 'Bhopal' },
//         { label: 'Mumbai', value: 'Mumbai' },
//         { label: 'Bengaluru', value: 'Bengaluru' },
//         { label: 'Hyderabad', value: 'Hyderabad' },
//         { label: 'Pune', value: 'Pune' },
//         { label: 'New Delhi', value: 'New Delhi' },
//     ];

//     const handleChange = (e) => {
//         e.preventDefault();
//         setSearchInput(e.target.value);
//     };
//     if (searchInput.length > 0) {
//         cities.filter((city) => {
//             return city.name.match(searchInput);
//         });
//     }
//     return(
//     <div>
//         <input type="search" placeholder="Search here" onChange={handleChange} value={searchInput} />
//         <table>
//             <tr>
//                 <th>City</th>
//             </tr>

//         {cities.map((city, index) =>{
//             <div>
//             <tr>
//               <td>{city.name}</td>
//             </tr>
//           </div>
//         })}
//         </table>
//     </div>
//     )
// };
// export default searchBar;
import React from "react"
import StudentProfile from "./StudentProfile"
import StuHeader from "./StuHeader"
import StudentHome from "./StudentHome"
import './StuStyle.css'



const Student = () => {
    return(
        <React.Fragment>
            <StuHeader />
            <StudentHome /> 
            
            
        </React.Fragment>
    )
}

export default Student;

{/* <div id="stu" className="stumn">
                <div className="navigation">
                    <ul style={{listStyle:"none", display:"Inline-block"}}>
                        <li>
                            Home
                            
                        </li>
                        <li>
                            Profile
                        </li>
                        <li>
                            Setting
                        </li>
                    </ul>
                    <StuHeader />
                </div>
            </div> */}
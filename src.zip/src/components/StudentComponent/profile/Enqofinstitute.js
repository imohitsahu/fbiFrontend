import axios from 'axios';
import React, { useEffect, useState } from 'react'

export default function Enqofinstitute(){
    // const [apiData, setApiData] = useState([]);
    // const [insEmail, setInsEmail] = useState();
    // const [stuName, setStuName] = useState();
    // const [stuEmail, setStuEmail] = useState("msahu7362@gmail.com");
    // const [enquiry, setEnquiry] = useState();
    // const [phoneNo, setPhoneNo] = useState();
    // const [insName, setInsName] = useState();

    // useEffect(() => {
    //     async function getData() {
    //         const res = await axios.get(`http://localhost:8080/api/Enquiry/stuenq/${stuEmail}`);
    //         // console.log(res.data);
    //         console.log(res.data.stuName)
    //         setInsEmail(res.data.insEmail);
    //         setStuName(res.data.stuName);
    //         setStuEmail(res.data.stuEmail);
    //         setEnquiry(res.data.enquiry);
    //         setPhoneNo(res.data.phoneNo);
    //         setInsName(res.data.insName);
    //     }
    //     getData();
    // },[])

    const index = 0;

    const [show, setShow] = useState(false)
    const handleShow = () => setShow(true);
    const handleClose = () => setShow(false);
    const [enquiryTemp, SetEnquiryTemp] = useState({
        insEmail: "",
        insName: "",
        stuName: "",
        stuEmail: "",
        enquiry: "",
        phoneNo: "",
    })
    const [apiData, setApiData] = useState([]);

    useEffect(() => {
        axios.get(`http://localhost:8080/api/Enquiry/stuenq/msahu7362@gmail.com`)
            .then((getData) => {
                setApiData(getData.data);
            })
    }, [])

    const setData = (insEmail, insName, stuName, stuEmail, enquiry, phoneNo) => {
        localStorage.setItem('insEmail', insEmail)
        localStorage.setItem('insName', insName)
        localStorage.setItem('stuName', stuName)
        localStorage.setItem('stuEmail', stuEmail)
        localStorage.setItem('enquiry', enquiry)
        localStorage.setItem('phoneNo', phoneNo)
    }

    const setID = (insEmail) => {
        console.log(insEmail)
        localStorage.setItem('insEmail', insEmail)
    }

    // const changeHandleEnquiry = (e) => {
    //     setEnquiryTemp((prevData) => ({
    //         ...prevData,
    //         [e.target.name]: e.target.value
    //     }))
    // };



    return (
        <div>
            <div className="p-2" ng-show='institutes_div'>
                <table className="table table-striped mx-auto">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Institute</th>
                            <th>Email</th>
                            <th>Enquiry</th>
                        </tr>
                    </thead>
                    {apiData.map((data) => {
                        return (
                            <tbody>
                                <tr>
                                    <td style={{textAlign :"left"}}>{index+1}</td>
                                    <td style={{textAlign :"left"}}>{data.insName}</td>
                                    <td style={{textAlign :"left"}}>{data.insEmail}</td>
                                    <td style={{textAlign :"left"}}>{data.enquiry}</td>

                                    {/* <td title='(( x.institute.address ))'>(( x.institute.address.substring(0 , 30)+'...' ))</td> */}
                                </tr>
                            </tbody>
                        )
                    })}
                </table>

            </div>
        </div>
    )
}

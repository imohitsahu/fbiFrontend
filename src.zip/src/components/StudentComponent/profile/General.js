import React, { useEffect, useState } from 'react'
import axios from 'axios'
import StudentService from '../../../services/StudentService';
import StuHeader from '../StuHeader';
import StudentProfile from '../StudentProfile';

function StuGeneral() {
  
  const [email, setEmail] = useState("msahu7362@gmail.com");
  const [name, setName] = useState();
  const [contact, setContact] = useState();
  const [city, setCity] = useState();
  const [state, setState] = useState();


  useEffect(() =>{
    async function getData(){
      const res = await StudentService.get(email)
      
      console.log(res.data);
      setName(res.data.stuName);
      setEmail(res.data.email);
      setContact(res.data.contactNo);
      setCity(res.data.city);
      setState(res.data.state);
    }
    getData();
  })

  return (
    <div>
      <StuHeader />
      <StudentProfile />
      <div className="p-2" ng-show='general_div' >
        <div className="row" style={{ color: "#333945" }}>
          <div className="col-lg-3 m-3 border rounded pl-4 pt-3 p-2 "
            style={{ backgroundColor: "deepskyblue" }}>
            <h5>Name</h5>
            <hr className="p-0 m-1 text-white bg-white" />
            <p>{name}</p>
          </div>

          <div className="col-lg-3 m-3 border rounded pl-4 pt-3 p-2 " style={{ backgroundColor: "#ced4da" }}>
            <h5>Email</h5>
            <hr className="p-0 m-1 text-white bg-white" />
            <p>{email}</p>
          </div>
          
          <div className="col-lg-3 m-3 border rounded pl-4 pt-3 p-2 " style={{ backgroundColor: "#ced4da" }}>
            <h5>Contact</h5>
            <hr className="p-0 m-1 text-white bg-white" />
            <p>{contact}</p>
          </div>
          <div className="col-lg-3 m-3 border rounded pl-4 pt-3 p-2 " style={{ backgroundColor: "#ced4da" }}>
            <h5>City</h5>
            <hr className="p-0 m-1 text-white bg-white" />
            <p>{city}</p>
          </div>
          <div className="col-lg-3 m-3 border rounded pl-4 pt-3 p-2 " style={{ backgroundColor: "#ced4da" }}>
            <h5>State</h5>
            <hr className="p-0 m-1 text-white bg-white" />
            <p>{state}</p>
          </div>
        </div>
      </div>
    </div>
  )
}
export default StuGeneral;
import React from "react"
import RegHeader from "./RegHeader"
import InstituteReg from "./InstituteRegistration"
import Footer from "../Footer"
import StudentReg from "./StudentRegistration"

const Registration = () => {
    return (
        <React.Fragment>
            <RegHeader />
            <div className="container" >
                <div className="row">
                    <div className="col-lg-6">
                        <InstituteReg />
                    </div>
                    <div className="col-lg-6">
                        <StudentReg />
                    </div>
                </div>
            </div>
            <Footer />
        </React.Fragment>
    )
}
export default Registration;
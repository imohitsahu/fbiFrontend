import React, { useEffect, useState } from 'react'
import { useLocation } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import { Backdrop, CircularProgress } from '@material-ui/core';
import { Button } from 'react-bootstrap'
import { Modal } from 'react-bootstrap'
import axios from 'axios';
import StudentService from '../../services/StudentService';

function Profile() {

    const location = useLocation();
    const [start, setStart] = useState(true);
    const [show, setShow] = useState(false);
    const [isGeneral, setIsGeneral] = useState(false)
    const [isChangePassword, setIsChangePassword] = useState(false)
    const [welcomeMsg, setWelcomeMsg] = useState("")
    const navigate = useNavigate()
    const [success, setSuccess] = useState(false);
    const [failure, setFailure] = useState(false);
    const [loading, setLoading] = useState(false);
    const [failureMsg, setFailureMsg] = useState("");
    const [students, setStudents] = useState([null])

    const[studentView, setStudentView] = useState({
        "email": "",
        "stuName": "",
        "password": "",
        "contactNo": "",
        "city": "",
        "state": ""
    })

    const handleClose = () => setShow(false);

    const [studentTemp, SetStudentTemp] = useState({
        email: "",
        stuName: "",
        password: "",
        contactNo: "",
        city: "",
        state: "",
    })

    const [stuName, SetStuName] = useState('')
    const [email, SetEmail] = useState('')
    const [contactNo, SetContactNo] = useState('')
    const [city, SetCity] = useState('')
    const [password, SetPassword] = useState('')
    const [state, SetState] = useState('')

    const [apiData, setApiData] = useState([]);

    const changePassword = () => {
        setIsGeneral(false)
        setIsChangePassword(true)
        setStart(false)

    };

    const general = () => {
        setIsGeneral(true)
        setIsChangePassword(false)
        setStart(false)

    };

    useEffect(() => {
        axios.get(`http://localhost:8080/api/student/all_Students`)
            .then((getData) => {
                setApiData(getData.data);
            })
    }, [])

    const sendDataToAPI = () => {
        axios.put(`http://localhost:8080/api/student/${studentTemp.email}`, studentTemp)
            .then((response) => {
                alert('Successfully Update', JSON.stringify(studentTemp))

            })
    }

    const updateStudent = (email) => {
        SetStudentTemp({
            email: apiData.find(it => it.email === email).email,
            stuName: apiData.find(it => it.email === email).stuName,
            password: apiData.find(it => it.email === email).password,
            contactNo: apiData.find(it => it.email === email).contactNo,
            city: apiData.find(it => it.email === email).city,
            state: apiData.find(it => it.email === email).state,
        })
        setShow(true)
    }

    const changeHandleStudent = (e) => {
        SetStudentTemp((prevData) => ({
            ...prevData,
            [e.target.name]: e.target.value
        }))
    };

    const handleSubmitStudentView = async (event) => {
        event.preventDefault();
        setLoading(true)
        const data = await StudentService.update(students.email, studentView)
        .then(response =>{
            setSuccess(true);
            setFailure(false)
        })
        .catch(error => {
            setFailureMsg(error.response.data)
            setSuccess(false);
            setFailure(true)
        })
        setLoading(false)
    };

    return (
        <>
            {loading && <Backdrop sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }} open={loading} onClick={handleClose}>
                <CircularProgress color="inherit" />
            </Backdrop>}
            {!loading && <>
                <nav className="navbar navbar-expand-sm navbar-dark Menu">
                    <div className="container-fluid">
                        <div className='navbar-header'>
                        </div>
                        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
                            <span className="navbar-toggler-icon"></span>
                        </button>
                        <div className="collapse navbar-collapse" id="collapsibleNavbar">
                            <ul className="navbar-nav">
                                <li className="nav-item">
                                    <button className='buttonStyle' data-bs-toggle="tooltip" title="General" onClick={() => updateStudent(studentTemp.email)} >General</button>
                                </li>
                                <li className="nav-item">
                                    <button className='buttonStyle' onClick={changePassword} >Password</button>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <p className='welcome'>Welcome: <b>{welcomeMsg}</b></p>
                <Modal show={show} onHide={handleClose} >
                    <Modal.Header closeButton>

                        <Modal.Title>Update Student</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <form className="form-body" onSubmit={handleSubmitStudentView} >
                            <p>Update</p>
                            <div className="username">
                                <label className="form__label">Full Name </label>
                                <input className="form__input" type="text" name="stuName" placeholder="Your Name" value={studentTemp.stuName} onChange={changeHandleStudent} required />
                            </div>

                            <div className="email">
                                <label className="form__label">Email </label>
                                <input type="email" className="form__input" name="email" placeholder="Email" value={studentTemp.email}
                                    pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Email should be in valid format.(ex: example@gmail.com)" onChange={changeHandleStudent} required />
                            </div>

                            <div className="contactno">
                                <label className="form__label">Phone No. </label>
                                <input type="tel" className="form__input" name="contactNo" placeholder="12345-67890" onChange={changeHandleStudent} pattern="^\d{10}$" title="Phone number should be in 10 digits without alphabets"
                                    value={studentTemp.contactNo} required />
                            </div>

                            <div className="city d-flex">
                                <label className="form__label">City</label>
                                <input type="text" className="form__input" name="city" placeholder="city" value={studentTemp.city} onChange={changeHandleStudent} required />
                            </div>

                            <div className="state d-flex">
                                <label className="form__label">State </label>
                                <input type="text" className="form__input" name="state" placeholder="state" value={studentTemp.state} onChange={changeHandleStudent} required />
                            </div>

                            <div className="password">
                                <label className="form__label">Password </label>
                                <input className="form__input" name="password" type="password" placeholder="Password" value={studentTemp.password} onChange={changeHandleStudent} required />
                            </div>
                            <div className="mt-3">
                                <Button variant="secondary" onClick={sendDataToAPI} style={{ backgroundColor: "#15B5B0" }}>
                                    Submit
                                </Button>
                                {/* <input type="submit" className="btn text-white form-control" value="Update"/> */}
                            </div>
                        </form>

                    </Modal.Body>
                    <div className='text-center'>
                        {/* {success && <p className='text-center text-success'>{successMsg}</p>}
                            {failure && <p className='text-center text-danger'>{failureMsg}</p>} */}
                    </div>
                    <Modal.Footer>
                        <Button variant="secondary" onClick={handleClose} style={{ backgroundColor: "#bd2130" }}>
                            Close
                        </Button>
                    </Modal.Footer>
                </Modal>

            </>}
        </>
    )
}

export default Profile
import axios from 'axios';
import React, { useEffect, useState } from 'react'
import InsHeader from './InsHeader'
import InstituteHome from './InstituteHome'
import CourseService from '../../services/CourseService';

function InsCourses() {
    
    const [changeEffect, SetChangeEffect] = useState(true)
    const [courses, setCourses] = useState(
        {
            insEmail: "sri@gmail.com",
            courseName: "",
            courseFee: ""
        });
    const [success, SetSuccess] = useState(false)
    const [failure, SetFailure] = useState(false)
    const [failureMessage, SetFailureMessage] = useState(null)
    const [loading, setLoading] = useState(false);
    const [show, setShow] = useState(false);
    const [isSubmit, setIsSubmit] = useState(false);
    const handleClose = () => setShow(false);

    const [formError, setFormError] = useState({})

    const changeHandle = e => {
        setCourses((prevData) => ({
            ...prevData,
            [e.target.name]: e.target.value
        }))
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        setFormError(validate(courses));
        setLoading(true)
        SetChangeEffect(false)
        const data = await CourseService.create(courses)
        .then(response => {

            console.log(response.data)
            alert("Courses Register Successfully " + JSON.stringify(courses));
            SetSuccess(true);
            SetFailure(false);
            SetChangeEffect(true)

        })
        .catch(error => {
            SetFailureMessage(error.response.data)
            SetSuccess(false);
            SetFailure(true)
        })
        setIsSubmit(false)
        setLoading(false)
    };

    const validate = (values) => {
        const errors = {}
    }

    const [apiData, setApiData] = useState([]);

    useEffect(() => {
        axios.get(`http://localhost:8080/api/course/getAllCoursesByEmail/sri@gmail.com`)
            .then((getData) => {
                setApiData(getData.data);
            })
    }, [changeEffect])

    const setID = (courseId) => {
        console.log(courseId)
        localStorage.setItem('courseId', courseId)
    }

    const getData = () => {
        axios.get(`http://localhost:8080/api/course/getAllCoursesByEmail/sri@gmail.com`)
            .then((getData) => {
                setApiData(getData.data);
            })

    }

    const onDelete = (courseId) => {
        axios.delete(`http://localhost:8080/api/course/${courseId}`)
            .then(() => {
                getData();
            })
        // window.location.reload(false);
    }
    let index = 0;

    return (
        <>
            <InsHeader />
            <InstituteHome />
            <div className="tab-pane fade show active" id="courses" role="tabpanel">
                <div className="row p-3 m-4">
                    <div className="form col-lg-4">
                        <form className="border p-4 m-2 rounded" onSubmit={handleSubmit}>
                            <div className="form-group">
                                <label>Course Name</label>
                                <input className="form-control" type="text" 
                                name="courseName" placeholder="Course Name"
                                value={courses.courseName}
                                onChange={changeHandle}
                                 required/>
                            </div>
                            <div className="form-group">
                                <label>Course Fee</label>
                                <input className="form-control" type="number"
                                name="courseFee" placeholder="Course Fee"
                                value={courses.courseFee}
                                onChange={changeHandle}
                                required=""/>
                            </div>
                            <div className="form-group">
                                <input type="submit" value="Save" className="btn form-control text-white" style={{ backgroundColor: "#15B5B0" }}/>
                            </div>
                        </form>
                    </div>
                    {/* <!-- All Courses Here --> */}
                    <div className="col-lg-7 mx-auto">
                        <table className="table table-striped">
                            <thead>
                                <th>Sno.</th>
                                <th>Course Name</th>
                                <th colSpan="2">Course Fees</th>
                            </thead>
                            <tbody>
                                {apiData.map((data) => {
                                    index++
                                    return (
                                        <tr ng-repeat='x in courses'>
                                            <td>{index}</td>
                                            <td>{data.courseName}</td>
                                            <td>Rs. {data.courseFee}</td>
                                            <td className="">
                                                <span className="close text-danger" onClick={() => onDelete(data.courseId)} title="Remove Course">&times;</span></td>
                                            {/* <td className="courseId" hidden>((x.id))</td> */}
                                        </tr>
                                    )
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </>
    )
}
export default InsCourses;

import axios from "axios";
import { Link } from "react-router-dom";
import React, { useEffect, useState } from "react";
import { Button } from 'react-bootstrap'
import InsHeader from './InsHeader'
import InstituteHome from './InstituteHome'

export default function InsEnquiry() {
    const [apiData, setApiData] = useState([]);

    useEffect(() => {
        axios.get(`http://localhost:8080/api/Enquiry/insenq/manipal@manipal.com`)
            .then((getData) => {
                setApiData(getData.data);
            })
    }, [])

    const setID = (insEmail) => {
        console.log(insEmail)
        localStorage.setItem('insEmail', insEmail)
    }

    const getData = () => {
        axios.get(`http://localhost:8080/api/Enquiry/insenq/manipal@manipal.com`)
            .then((getData) => {
                setApiData(getData.data);
            })
    }

    const onDelete = (enqId) => {
        axios.delete(`http://localhost:8080/api/Enquiry/${enqId}`)
            .then(() => {
                getData();
            })
        // window.location.reload(false);
    }
    let index = 0;



    return (
        <>
            <InsHeader />
            <InstituteHome />
            <div className="tab-pane fade show active" role="tabpanel" >
                <div className="p-3  mx-auto text-center">
                    {/* <div className="col-lg-5 mx-auto rounded border mt-4">
                        <h1 className="text-center display-4 p-4">No Enquiries</h1>
                    </div> */}
                    <table className="table table-responsive mx-auto table-striped" ng-show='enquiries.length>0'>
                        <thead>
                            <tr>
                                <th>Sno.</th>
                                <th>Course</th>
                                <th>Course Fees</th>
                                <th>Student</th>
                                <th>Contact</th>
                                <th>Email</th>
                                <th>Address</th>
                            </tr>
                        </thead>
                        <tbody>
                            {apiData.map((data) => {
                                index++
                                return (
                                    
                                    <tr ng-repeat='x in enquiries'>
                                        <td>{index}</td>
                                        <td>course</td>
                                        <td>courseFee</td>
                                        <td>{data.stuName}</td>
                                        <td>{data.phoneNo}</td>
                                        <td>{data.stuEmail}</td>
                                        
                                        <td>
                                            <span className="icon material-icons text-danger m-2" onClick={() => onDelete(data.enqId)} title="Remove From Enquiry" >delete </span>
                                        </td>
                                        {/* <td>
                                            <span className="icon material-icons text-success m-2" title="Mark Admitted" ng-click='markAdmitted(x.enquiryId , $index)'>check_circle</span>
                                        </td> */}
                                    </tr>
                                )
                            })}
                        </tbody>
                    </table>
                </div>
            </div >
        </>
    )
}

import React from 'react';
import { Link } from 'react-router-dom';
import { InsCourses } from './InsCourses';

function InstituteHome() {
    return (
        <>
            <div className="container p-4">
                <nav>
                    <div className="nav nav-tabs" id="nav-tab" role="tablist">
                        <Link className="nav-item nav-link" data-toggle="tab" to="/institute" role="tab">Courses</Link>
                        <Link className="nav-item nav-link" data-toggle="tab" to="/insenq" role="tab">
                            Enquiry <span className="badge badge-success">3</span>
                        </Link>
                        {/* <Link className="nav-item nav-link" data-toggle="tab" to="/insstu" role="tab">
                            Students <span className="badge badge-success">(( admitted.length ))</span>
                        </Link> */}
                        <Link className="nav-item nav-link" data-toggle="tab" to="/inspro" role="tab">Profile</Link>
                        <Link className="nav-item nav-link" data-toggle="tab" to="/inspass" role="tab">Settings</Link>
                    </div>
                </nav>
            </div>
        </>
    )
}
export default InstituteHome;
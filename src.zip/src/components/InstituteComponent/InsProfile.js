import React, { useState, useEffect } from "react"
import InsHeader from "./InsHeader"
import InstituteHome from "./InstituteHome"
import InstituteService from "../../services/InstituteService"

export default function InsProfile() {
    const [email, setEmail] = useState("manipal@manipal.com");
    const [insName, setInsName] = useState();
    const [contact, setContact] = useState();
    const [city, setCity] = useState();
    const [state, setState] = useState();
    const [map, setMap] = useState();
    const [status, setStatus] = useState();

    useEffect(() => {
        async function getData() {
            const res = await InstituteService.get(email)

            console.log(res.data);
            setInsName(res.data.insName);
            setEmail(res.data.email);
            setContact(res.data.contactNo);
            setCity(res.data.city);
            setState(res.data.state);
            setMap(res.data.map);
            setStatus(res.data.status);
        }
        getData();
    })

    return (
        <>
            <InsHeader />
            <InstituteHome />
            <div className="tab-pane fade show active" id="profile" role="tabpanel" >
                <div className="p-2" ng-show='general_div' >
                    <div className="row" style={{ color: "#333945" }}>
                        <div className="col-lg-3 m-3 border rounded pl-4 pt-3 p-2 "
                            style={{ backgroundColor: "deepskyblue" }}>
                            <h5>Name</h5>
                            <hr className="p-0 m-1 text-white bg-white" />
                            <p>{insName}</p>
                        </div>
                        <div className="col-lg-3 m-3 border rounded pl-4 pt-3 p-2 " style={{ backgroundColor: "(( getColor(1) ))" }}>
                            <h5>Email</h5>
                            <hr className="p-0 m-1 text-white bg-white" />
                            <p>{email}</p>
                        </div>
                        <div className="col-lg-3 m-3 border rounded pl-4 pt-3 p-2 " style={{ backgroundColor: "(( getColor(3) ))" }}>
                            <h5>Contact</h5>
                            <hr className="p-0 m-1 text-white bg-white" />
                            <p>{contact}</p>
                        </div>
                        <div className="col-lg-3 m-3 border rounded pl-4 pt-3 p-2 " style={{ backgroundColor: "(( getColor(4) ))" }}>
                            <h5>City</h5>
                            <hr className="p-0 m-1 text-white bg-white" />
                            <p>{city}</p>
                        </div>
                        <div className="col-lg-3 m-3 border rounded pl-4 pt-3 p-2 " style={{ backgroundColor: "(( getColor(5) ))" }}>
                            <h5>State</h5>
                            <hr className="p-0 m-1 text-white bg-white" />
                            <p>{state}</p>
                        </div>
                        {/* <div className="col-lg-3 m-3 border rounded pl-4 pt-3 p-2 " style={{ backgroundColor: "(( getColor(2) ))" }}>
                            <h5>Status</h5>
                            <hr className="p-0 m-1 text-white bg-white" />
                            <p>{status}</p>
                        </div> */}
                    </div>
                </div>
            </div>
        </>
    )
}
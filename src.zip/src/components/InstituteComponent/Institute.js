import React from "react";
import InsHeader from "./InsHeader";
import InstituteHome from "./InstituteHome";

const Institute = () => {
    return(
        <React.Fragment>
            <InsHeader />
            <InstituteHome />
        </React.Fragment>
    )
}

export default Institute;